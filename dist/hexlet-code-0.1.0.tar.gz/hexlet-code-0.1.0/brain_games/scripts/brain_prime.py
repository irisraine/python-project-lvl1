#!/usr/bin/env python

from brain_games.common.engine import launch
from brain_games.games import prime


def main():
    launch(prime)
