def is_correct_answer(answer, correct_answer):
    if (answer == correct_answer):
        print('Correct!')
        return True
    else:
        print(f"'{answer}' is wrong answer ;(. Correct answer was '{correct_answer}'.")
