#!/usr/bin/env python

from brain_games.logic.even_logic import guessing_even_number


def main():
    guessing_even_number()


if __name__ == '__main__':
    main()
