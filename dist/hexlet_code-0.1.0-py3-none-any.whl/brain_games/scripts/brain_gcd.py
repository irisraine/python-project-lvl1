#!/usr/bin/env python

from brain_games.common.launcher import launch


def main():
    launch("gcd")
