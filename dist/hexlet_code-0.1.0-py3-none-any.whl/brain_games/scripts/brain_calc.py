#!/usr/bin/env python

from brain_games.common.engine import launch


def main():
    launch("calc")
