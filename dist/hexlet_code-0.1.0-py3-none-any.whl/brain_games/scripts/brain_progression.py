#!/usr/bin/env python

from brain_games.common.engine import launch
import brain_games.games.progression


def main():
    launch(brain_games.games.progression)
